"""HR Training chatbot package."""
